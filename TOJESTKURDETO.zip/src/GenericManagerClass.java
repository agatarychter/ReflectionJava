import java.lang.reflect.*;
import static java.lang.reflect.Modifier.isStatic;

class GenericManagerClass {
    static <T> T makeNewInstance(Class<T> cls) {
        T t;
        try {
            t = cls.newInstance();
            return t;
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    static <T> T makeNewInstance(Class<T> cls, Object... arg){
        T t;
        try {
            for (Constructor<?> constructor : cls.getConstructors()) {
                if (constructor.getParameterCount() > 0) {
                    Class[] classes = new Class[arg.length];
                    for (int i = 0; i < classes.length; i++) {
                        classes[i] = arg[i].getClass();
                    }

                    t = cls.getConstructor(classes).newInstance(arg);
                    return t;
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }



    static <T> T[] createArray(Class<T> cls, int size)
    {
        @SuppressWarnings("unchecked")
        T[] array = (T[]) Array.newInstance(cls, size);
        return array;
    }
    
    static <T> T clone(T object, Class<T> cls)//works only for objects of class having 0-parameter constructor
    {
//        Class<?> cls = object.getClass();
        T t = makeNewInstance(cls);
        try {
            Field[] f = object.getClass().getDeclaredFields();

            for (int i = 0; i < f.length; i++) {
                Field field = f[i];
                if(!isStatic(field.getModifiers()))
                {
                    field.setAccessible(true);
                    field.set(t, field.get(object));
                }
            }
            return t;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    static <T> Pair<T> clonePair(Pair<T> object, Class<T> cls)
    {
        T t1 = makeNewInstance(cls);
        T t2 = makeNewInstance(cls);
        try {
            System.out.println("Fields =");

            Field[] f = cls.getFields();
            for (int i = 0; i < f.length; i++) {
                Field field = f[i];
                field.setAccessible(true);
                field.set(t1, field.get(object.getFirst()));
                field.set(t2,field.get(object.getSecond()));
            }
            return new Pair<T>(t1,t2);
        } catch (Exception e) {
                    e.printStackTrace();
        }
        return null;
    }

    static <T> T clone2(T object, Class<T> cls)
    {
        T t = makeNewInstance(cls);
        try {
            System.out.println("Fields =");

            Field[] f = cls.getFields();
            System.out.println(f.length);
            for (int i = 0; i < f.length; i++) {
                Field field = f[i];
                field.setAccessible(true);
                field.set(t, field.get(object));
                System.out.println(field.getName());
            }
            return t;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
