public class SimpleClass {
    int a = 5;
    int b = 4;
    Pair pair;

    public SimpleClass()
    {}

    public SimpleClass(Pair pair)
    {
        this.pair = pair;
    }



}
