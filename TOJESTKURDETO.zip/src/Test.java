import java.lang.reflect.Field;
import java.util.Arrays;

public class Test {
    public static void main (String[] args)
    {
        SimpleClass simpleClass = GenericManagerClass.makeNewInstance(SimpleClass.class);
        System.out.println(simpleClass);

        String string = GenericManagerClass.makeNewInstance(String.class);
        if(string != null)
        {
            System.out.println("not null");
        }

        System.out.println(Arrays.toString(GenericManagerClass.createArray(String.class, 5)));
        System.out.println(Arrays.toString(GenericManagerClass.createArray(SimpleClass.class, 10)));
        SimpleClass simpleClass1 = new SimpleClass();
        Pair<SimpleClass> pair = new Pair<>(simpleClass, simpleClass1);
        Pair<SimpleClass> pair2 = GenericManagerClass.clonePair(pair, SimpleClass.class);
        System.out.println(pair2.getSecond().a);
        simpleClass1.a = 2;
        System.out.println(pair.getSecond().a);
        System.out.println(pair2.getSecond().a);

        Pair<SimpleClass> pairClonePair = GenericManagerClass.clone(pair, Pair.class);
        System.out.println("Pair cloned" + pairClonePair.getFirst().a);

        String s = "g";
        String g = GenericManagerClass.clone(s, String.class);
        System.out.println("Cloned String: " + g);

        Field[] f = String.class.getFields();
        System.out.println(Arrays.toString(f));

        Integer j = GenericManagerClass.makeNewInstance(Integer.class, "5");
        SimpleClass sc = GenericManagerClass.makeNewInstance(SimpleClass.class, new Pair<SimpleClass>());



    }
}
